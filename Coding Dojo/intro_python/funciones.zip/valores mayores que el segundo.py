#Escribe una función que acepte una lista y cree una nueva 
# que contenga solo los valores de la lista original que sean mayores que su segundo valor. 
# Imprime cuántos valores son y luego devuelve la lista nueva. Si la lista tiene menos de 2 elementos, has que la función devuelva False
#Ejemplo: values_greater_than_second([5,2,3,2,1,4]) debe imprimir 3 y devolver [5,3,4]
#Ejemplo: values_greater_than_second([3]) debe devolver False
def longval(lista):
    lista1 = []
    a = lista[1]
    for i in lista:
        if i > a:
            lista1.append(i)
    largo = len(lista1)    
    if largo < 2:
            print("false")
    else:
        print(f'son', len(lista1), "valores")
        print(f'esta es la lista nueva', lista1) 

    

lista = [5,2,3,2,1,4]
longval(lista)
