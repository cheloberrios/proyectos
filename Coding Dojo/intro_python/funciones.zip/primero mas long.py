#Crea una función que acepte una lista y devuelva la suma del primer valor de la lista, más la longitud de la lista.
def primalong(lista):
    a = lista[0]
    b = len(lista)
    return print(a + b)

lista = [1,2,3,4,5,6]
primalong(lista)
