#Crea una función que tome una lista y devuelva la longitud de la lista.
#Ejemplo: length([37,2,1,-9]) debería devolver 4
#Ejemplo: length([]) debería devolver 0
def promedio(lista):
    largo = 0
    largo = largo + len(lista)
    print(largo)
    return largo

promedio([37,2,1,-9])

